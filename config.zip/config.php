<?php
$conn = new mysqli("sql303.infinityfree.com", "if0_38712300
", "5kdbwkRA4LChW ", "if0_38712300_XXX");

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
